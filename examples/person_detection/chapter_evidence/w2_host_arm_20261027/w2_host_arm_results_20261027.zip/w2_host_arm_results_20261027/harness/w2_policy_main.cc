// W2 policy harness: line protocol shared by host, Arm (QEMU) and ESP32 builds.
//   "W2 o0 o1 o2 o3 o4 o5 o6"  (int8 observation)  ->  "A a0 a1"  (int8 action)
//   "ID"  -> identity line;  "Q" -> exit
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tensorflow/lite/micro/examples/w2_policy/w2_model_data.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/schema/schema_generated.h"

namespace {
constexpr int kArenaSize = 16 * 1024;
alignas(16) uint8_t tensor_arena[kArenaSize];
}

int main(int argc, char** argv) {
  const tflite::Model* model = tflite::GetModel(g_w2_model);
  static tflite::MicroMutableOpResolver<1> resolver;
  resolver.AddFullyConnected();
  static tflite::MicroInterpreter interpreter(model, resolver, tensor_arena, kArenaSize);
  if (interpreter.AllocateTensors() != kTfLiteOk) { printf("W2_ERROR allocate\n"); return 1; }
  TfLiteTensor* in = interpreter.input(0);
  TfLiteTensor* out = interpreter.output(0);
  printf("W2_READY model_sha256=%s arena_used=%d\n", g_w2_model_sha256, (int)interpreter.arena_used_bytes());
  fflush(stdout);
  char line[160];
  while (fgets(line, sizeof(line), stdin)) {
    if (line[0] == 'Q') break;
    if (line[0] == 'I' && line[1] == 'D') { printf("ID model_sha256=%s\n", g_w2_model_sha256); fflush(stdout); continue; }
    if (line[0] != 'W' || line[1] != '2') continue;
    char* p = line + 2;
    for (int i = 0; i < 7; ++i) in->data.int8[i] = (int8_t)strtol(p, &p, 10);
    if (interpreter.Invoke() != kTfLiteOk) { printf("A_ERROR\n"); fflush(stdout); continue; }
    printf("A %d %d\n", (int)out->data.int8[0], (int)out->data.int8[1]);
    fflush(stdout);
  }
  return 0;
}
