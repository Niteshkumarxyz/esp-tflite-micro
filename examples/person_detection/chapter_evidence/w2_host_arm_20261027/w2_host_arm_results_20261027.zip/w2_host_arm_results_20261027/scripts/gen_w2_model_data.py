"""Write w2_model_data.{cc,h} from a .tflite file (bytes copied verbatim; SHA-256 embedded)."""
import hashlib, sys
src, out = sys.argv[1], sys.argv[2]
b = open(src, 'rb').read(); h = hashlib.sha256(b).hexdigest()
rows = ',\n'.join(','.join(str(v) for v in b[i:i + 32]) for i in range(0, len(b), 32))
open(f'{out}/w2_model_data.cc', 'w').write(
    '#include "tensorflow/lite/micro/examples/w2_policy/w2_model_data.h"\n'
    f'// {src.split("/")[-1]}, {len(b)} bytes\n'
    f'const char g_w2_model_sha256[] = "{h}";\n'
    f'alignas(16) const unsigned char g_w2_model[{len(b)}] = {{\n{rows}}};\n'
    f'const int g_w2_model_len = {len(b)};\n')
open(f'{out}/w2_model_data.h', 'w').write('#ifndef W2_MODEL_DATA_H_\n#define W2_MODEL_DATA_H_\n'
    'extern const char g_w2_model_sha256[];\nextern const unsigned char g_w2_model[];\nextern const int g_w2_model_len;\n#endif\n')
print(h)
