"""Write main/w2_models.cc for the ESP32 firmware from the per-tensor and per-channel .tflite files."""
import hashlib, sys
pt, pc, out = sys.argv[1], sys.argv[2], sys.argv[3]
def block(name, path):
    b = open(path, 'rb').read(); h = hashlib.sha256(b).hexdigest()
    rows = ',\n'.join(','.join(str(v) for v in b[i:i + 32]) for i in range(0, len(b), 32))
    return (f'// {path.split("/")[-1]}\nconst char g_w2_model_{name}_sha256[] = "{h}";\n'
            f'alignas(16) const unsigned char g_w2_model_{name}[{len(b)}] = {{\n{rows}}};\n'
            f'const int g_w2_model_{name}_len = {len(b)};\n\n'), h
a, ha = block('pt', pt); c, hc = block('pc', pc)
open(f'{out}/w2_models.cc', 'w').write('#include "w2_models.h"\n\n' + a + c)
print('pt', ha); print('pc', hc)
