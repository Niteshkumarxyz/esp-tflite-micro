"""W2 open-loop (RQ1) and closed-loop (RQ2) comparison across runtimes.

Usage: python w2_eval.py OUT_DIR MODEL_NAME RUNTIMES_JSON
  OUT_DIR       folder with w2_models.json and the .tflite files
  MODEL_NAME    per_tensor or per_channel
  RUNTIMES_JSON list of {"name": ..., "kind": "litert", "mode": "REF|OPT|XNN"} or
                {"name": ..., "kind": "proc", "cmd": [...]}
The first runtime in the list is the reference for all comparisons.
"""
import csv
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import w2_sim as S  # noqa: E402
from w2_runtime import LineProc, LiteRT, ModelMeta, mcnemar_exact, run_episode  # noqa: E402

OUT, NAME, RT_JSON = sys.argv[1], sys.argv[2], sys.argv[3]
meta = ModelMeta(os.path.join(OUT, "w2_models.json"), NAME)
model_path = os.path.join(OUT, f"w2_actor_int8_{NAME}.tflite")
assert hashlib.sha256(open(model_path, "rb").read()).hexdigest() == meta.sha256
RES = os.path.join(OUT, f"eval_{NAME}")
os.makedirs(RES, exist_ok=True)
CLOSED_SEEDS = list(range(3000, 3200))   # disjoint from training (1e7+), calibration (2000-2199), training eval (500-539)


def make(rt):
    if rt["kind"] == "litert":
        return LiteRT(model_path, rt["mode"])
    return LineProc(rt["cmd"], rt["name"])


# ---- open-loop observation set: 50,000 int8 observations -------------------------------------
def open_loop_set():
    path = os.path.join(RES, "openloop_obs_int8.npy")
    if os.path.exists(path):
        return np.load(path)
    w = np.load(os.path.join(OUT, "actor_weights.npz"))

    def fpol(o):
        h = np.maximum(o @ w["W0"] + w["b0"], 0)
        h = np.maximum(h @ w["W1"] + w["b1"], 0)
        return h @ w["W2"] + w["b2"]
    rng = np.random.default_rng(42)
    roll = []
    sd = 4000
    while len(roll) < 25000:
        e = S.RowEnv(sd)
        o = e.reset_obs()
        while not e.done and len(roll) < 25000:
            roll.append(o)
            o, _, _ = e.step(fpol(o))
        sd += 1
    roll = np.array(roll)
    # boundary half: (a) rollout states pushed by +/-2 input quantization steps,
    # (b) uniform states over the whole input range, (c) saturated sensors (0 or 1)
    a = roll[rng.integers(0, len(roll), 10000)] + rng.integers(-2, 3, (10000, 7)) * meta.in_scale
    b = rng.uniform(0, 1, (10000, 7))
    c = roll[rng.integers(0, len(roll), 5000)].copy()
    mask = rng.random((5000, 7)) < 0.3
    c[mask] = rng.integers(0, 2, mask.sum())
    allobs = np.clip(np.concatenate([roll, a, b, c]), 0, 1)
    Q = np.array([meta.q_obs(o) for o in allobs], dtype=np.int8)
    np.save(path, Q)
    return Q


runtimes = json.load(open(RT_JSON))
Q = open_loop_set()
summary = {"model": NAME, "model_sha256": meta.sha256, "open_loop_n": int(len(Q)), "closed_loop_seeds": [CLOSED_SEEDS[0], CLOSED_SEEDS[-1]],
           "runtimes": {}}
ref_open = None
ref_closed = None
for rt in runtimes:
    t0 = time.time()
    r = make(rt)
    A = r.batch(Q)
    np.save(os.path.join(RES, f"openloop_actions_{rt['name']}.npy"), A)
    episodes = []
    traj = {}
    for sd in CLOSED_SEEDS:
        m, steps = run_episode(sd, r, meta, record=True)
        episodes.append(m)
        traj[sd] = steps
    r.close()
    np.savez_compressed(os.path.join(RES, f"closed_loop_trajectories_{rt['name']}.npz"),
                        **{str(sd): np.frombuffer(b"".join(o + a for o, a in traj[sd]), dtype=np.int8).reshape(-1, 9)
                           for sd in CLOSED_SEEDS})
    rec = {"open_loop_actions_sha256": hashlib.sha256(A.tobytes()).hexdigest(),
           "success": int(sum(m["success"] for m in episodes)),
           "mean_rms_xte_m": float(np.mean([m["rms_xte"] for m in episodes])),
           "mean_steps": float(np.mean([m["steps"] for m in episodes])),
           "seconds": round(time.time() - t0, 1)}
    if ref_open is None:
        ref_open, ref_closed, ref_eps = A, traj, episodes
        rec["role"] = "reference"
    else:
        d = A.astype(np.int16) - ref_open.astype(np.int16)
        anyd = np.any(d != 0, axis=1)
        rec["open_loop_disagree"] = int(anyd.sum())
        rec["open_loop_disagree_rate"] = float(anyd.mean())
        rec["open_loop_max_lsb"] = int(np.abs(d).max())
        rec["open_loop_disagree_by_part"] = {k: int(anyd[s:e].sum()) for k, (s, e) in
                                             {"rollout": (0, 25000), "near_rollout": (25000, 35000),
                                              "uniform": (35000, 45000), "saturated": (45000, 50000)}.items()}
        sep = []
        same_traj = 0
        for sd in CLOSED_SEEDS:
            a, b = ref_closed[sd], traj[sd]
            k = next((i for i in range(min(len(a), len(b))) if a[i] != b[i]), None)
            if k is None and len(a) == len(b):
                same_traj += 1
            else:
                sep.append(k if k is not None else min(len(a), len(b)))
        rec["closed_loop_identical_episodes"] = same_traj
        rec["closed_loop_first_separation_steps"] = sep
        b_ = sum(1 for x, y in zip(ref_eps, episodes) if x["success"] and not y["success"])
        c_ = sum(1 for x, y in zip(ref_eps, episodes) if not x["success"] and y["success"])
        rec["mcnemar_ref_only_success"], rec["mcnemar_this_only_success"] = b_, c_
        rec["mcnemar_exact_p"] = mcnemar_exact(b_, c_)
        rec["outcome_changed_seeds"] = [x["seed"] for x, y in zip(ref_eps, episodes) if x["success"] != y["success"]]
    summary["runtimes"][rt["name"]] = rec
    with open(os.path.join(RES, f"closed_loop_{rt['name']}.csv"), "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(episodes[0].keys()))
        wr.writeheader()
        wr.writerows(episodes)
    print(rt["name"], json.dumps({k: v for k, v in rec.items() if k != "closed_loop_first_separation_steps"}), flush=True)
json.dump(summary, open(os.path.join(RES, "summary.json"), "w"), indent=1)
