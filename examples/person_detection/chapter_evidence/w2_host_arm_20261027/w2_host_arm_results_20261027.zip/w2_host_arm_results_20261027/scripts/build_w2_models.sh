#!/bin/bash
# Build the W2 harness for both int8 models across all TFLM configurations and keep the binaries.
set -e
EX=/home/claude/arm/tflm/tensorflow/lite/micro/examples/w2_policy
for m in per_tensor per_channel; do
  python3 /home/claude/w2/gen_w2_model_data.py /home/claude/w2/out/w2_actor_int8_$m.tflite $EX
  /home/claude/arm/build_w2_all.sh > /home/claude/w2/build_$m.out 2>&1
  D=/home/claude/w2/bins/$m; mkdir -p $D
  cd /home/claude/arm/tflm
  cp gen_w2/linux_x86_64_default_gcc/bin/w2_policy                        $D/x86_ref
  cp gen_w2_sr/linux_x86_64_default_gcc/bin/w2_policy                     $D/x86_ref_sr
  cp gen_w2/cortex_m_qemu_cortex-m4_default_gcc/bin/w2_policy             $D/m4_ref
  cp gen_w2/cortex_m_qemu_cortex-m4_default_cmsis_nn_gcc/bin/w2_policy    $D/m4_cmsis
  cp gen_w2_sr/cortex_m_qemu_cortex-m4_default_cmsis_nn_gcc/bin/w2_policy $D/m4_cmsis_sr
  cp gen_w2/cortex_m_qemu_cortex-m3_default_cmsis_nn_gcc/bin/w2_policy    $D/m3_cmsis
  cp gen_w2/cortex_m_qemu_hf_cortex-m55_default_cmsis_nn_gcc/bin/w2_policy $D/m55_cmsis
  cp gen_w2/cortex_m_qemu_cortex-m0plus_default_gcc/bin/w2_policy         $D/m0p_ref
  cat /home/claude/w2/build_$m.out
done
