W2_SRCS := $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/w2_policy/w2_policy_main.cc \
           $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/w2_policy/w2_model_data.cc
W2_HDRS := $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/w2_policy/w2_model_data.h
$(eval $(call microlite_test,w2_policy,$(W2_SRCS),$(W2_HDRS),))
