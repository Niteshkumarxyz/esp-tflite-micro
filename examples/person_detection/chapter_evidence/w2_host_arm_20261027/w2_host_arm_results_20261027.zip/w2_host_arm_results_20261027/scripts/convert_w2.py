"""Quantize the W2 actor to full-int8 TFLite, per-tensor and per-channel, from the PPO float weights.

Usage: python convert_w2.py OUT_DIR
Calibration data: observations from float-policy rollouts on seeds 2000-2199 (disjoint from
training seeds and from the evaluation seeds used later).
"""
import hashlib
import json
import os
import sys

import numpy as np
import tensorflow as tf

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import w2_sim as S  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
w = np.load(os.path.join(OUT, "actor_weights.npz"))


def keras_actor():
    m = tf.keras.Sequential([
        tf.keras.Input(shape=(7,), dtype=tf.float32),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(2),
    ])
    for i, layer in enumerate(m.layers):
        layer.set_weights([w[f"W{i}"], w[f"b{i}"]])
    return m


actor = keras_actor()


def float_policy(o):
    return actor(o[None, :].astype(np.float32), training=False).numpy()[0]


calib = []
for sd in range(2000, 2200):
    e = S.RowEnv(sd)
    o = e.reset_obs()
    while not e.done:
        calib.append(o)
        o, _, _ = e.step(float_policy(o))
calib = np.array(calib, dtype=np.float32)
np.save(os.path.join(OUT, "calibration_obs.npy"), calib)
print("calibration observations", calib.shape)

rng = np.random.default_rng(0)
idx = rng.choice(len(calib), size=min(2000, len(calib)), replace=False)


def rep():
    for i in idx:
        yield [calib[i:i + 1]]


info = {}
for name, disable_pc in (("per_tensor", True), ("per_channel", False)):
    conv = tf.lite.TFLiteConverter.from_keras_model(actor)
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    conv.representative_dataset = rep
    conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    conv.inference_input_type = tf.int8
    conv.inference_output_type = tf.int8
    conv._experimental_disable_per_channel_quantization_for_dense_layers = disable_pc
    b = conv.convert()
    path = os.path.join(OUT, f"w2_actor_int8_{name}.tflite")
    open(path, "wb").write(b)
    it = tf.lite.Interpreter(model_content=b)
    it.allocate_tensors()
    ops = sorted({d["op_name"] for d in it._get_ops_details()})
    scales = []
    for d in it.get_tensor_details():
        q = d["quantization_parameters"]
        if d["dtype"] == np.int8 and len(d["shape"]) == 2 and d["shape"][0] in (64, 2) and d["shape"][1] in (7, 64):
            scales.append((d["name"][:40], [int(v) for v in d["shape"]], int(len(q["scales"]))))
    inp, outp = it.get_input_details()[0], it.get_output_details()[0]
    info[name] = dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest(), ops=ops, weight_scale_counts=scales,
                      input_scale=float(inp["quantization"][0]), input_zero_point=int(inp["quantization"][1]),
                      output_scale=float(outp["quantization"][0]), output_zero_point=int(outp["quantization"][1]))
    print(name, json.dumps(info[name]))
json.dump(info, open(os.path.join(OUT, "w2_models.json"), "w"), indent=1)
