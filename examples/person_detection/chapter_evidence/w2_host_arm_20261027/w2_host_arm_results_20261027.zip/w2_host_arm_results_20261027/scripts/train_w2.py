"""Train the W2 row-following policy with PPO (MLP 64-64, ReLU), then export float weights.

Usage: python train_w2.py TOTAL_STEPS OUT_DIR
Seeds are fixed so training is repeatable on the same software stack.
"""
import json
import os
import sys
import time

import numpy as np

# TensorFlow and PyTorch in one process crash this stack; keep TF out of the training process.
sys.modules["tensorflow"] = None
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import w2_sim as S  # noqa: E402

TOTAL = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
OUT = sys.argv[2] if len(sys.argv) > 2 else "out"
os.makedirs(OUT, exist_ok=True)
torch.manual_seed(0)
np.random.seed(0)
torch.set_num_threads(1)


def make(i):
    return lambda: S.RowGym(seed_base=i * 1_000_000)


env = make_vec_env(lambda: S.RowGym(), n_envs=4, seed=0)
for i, e in enumerate(env.envs):
    e.unwrapped._n = i * 1_000_000
model = PPO(
    "MlpPolicy", env, seed=0, verbose=0,
    n_steps=1024, batch_size=256, n_epochs=10, gamma=0.998, gae_lambda=0.95,
    learning_rate=3e-4, ent_coef=0.0, clip_range=0.2,
    policy_kwargs=dict(net_arch=dict(pi=[64, 64], vf=[64, 64]), activation_fn=torch.nn.ReLU, log_std_init=-0.5),
)

with torch.no_grad():
    model.policy.action_net.bias.fill_(0.6)  # start near forward speed so steering must be learned


def evaluate(policy_fn, seeds):
    out = []
    for sd in seeds:
        e = S.RowEnv(sd)
        o = e.reset_obs()
        while not e.done:
            o, _, _ = e.step(policy_fn(o))
        out.append(e.metrics())
    return out


def det(o):
    a, _ = model.predict(o, deterministic=True)
    return a


t0 = time.time()
chunk = 100_000
log = []
done = 0
while done < TOTAL:
    model.learn(total_timesteps=min(chunk, TOTAL - done), reset_num_timesteps=False)
    done += chunk
    ev = evaluate(det, range(500, 540))
    rec = dict(steps=done, success=sum(m["success"] for m in ev) / len(ev),
               rms=float(np.mean([m["rms_xte"] for m in ev])), minutes=round((time.time() - t0) / 60, 1))
    log.append(rec)
    print(json.dumps(rec), flush=True)
model.save(os.path.join(OUT, "ppo_w2"))

# export the deterministic actor as plain arrays: Dense(64, relu) -> Dense(64, relu) -> Dense(2)
pn = model.policy.mlp_extractor.policy_net
layers = [pn[0], pn[2], model.policy.action_net]
np.savez(os.path.join(OUT, "actor_weights.npz"),
         **{f"W{i}": l.weight.detach().numpy().T for i, l in enumerate(layers)},
         **{f"b{i}": l.bias.detach().numpy() for i, l in enumerate(layers)})
json.dump(log, open(os.path.join(OUT, "train_log.json"), "w"), indent=1)
print("saved", OUT)
