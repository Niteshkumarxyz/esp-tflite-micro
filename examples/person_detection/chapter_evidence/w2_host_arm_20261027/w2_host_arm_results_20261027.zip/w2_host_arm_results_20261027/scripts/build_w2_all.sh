#!/bin/bash
# Build the W2 harness for every TFLM configuration with tracing off. Model data must already be generated.
cd /home/claude/arm/tflm
MK="make -s -j2 -f tensorflow/lite/micro/tools/make/Makefile -f /home/claude/arm/w2.mk BASE_GENDIR=gen_w2"
b(){ name=$1; shift; if timeout 2400 $MK "$@" w2_policy > /home/claude/arm/build_w2_$name.log 2>&1; then echo "OK $name"; else echo "FAIL $name"; tail -4 /home/claude/arm/build_w2_$name.log; fi; }
b x86_ref        "ADDITIONAL_DEFINES=-DRQ1_NO_TRACE"
b x86_ref_sr     BASE_GENDIR=gen_w2_sr "ADDITIONAL_DEFINES=-DRQ1_NO_TRACE -DTFLITE_SINGLE_ROUNDING=1"
b m4_ref         TARGET=cortex_m_qemu TARGET_ARCH=cortex-m4 "ADDITIONAL_DEFINES=-DRQ1_NO_TRACE"
b m4_cmsis       TARGET=cortex_m_qemu TARGET_ARCH=cortex-m4 OPTIMIZED_KERNEL_DIR=cmsis_nn "ADDITIONAL_DEFINES=-DCMSIS_NN -DRQ1_NO_TRACE"
b m4_cmsis_sr    BASE_GENDIR=gen_w2_sr TARGET=cortex_m_qemu TARGET_ARCH=cortex-m4 OPTIMIZED_KERNEL_DIR=cmsis_nn "ADDITIONAL_DEFINES=-DCMSIS_NN -DRQ1_NO_TRACE -DTFLITE_SINGLE_ROUNDING=1 -DCMSIS_NN_USE_SINGLE_ROUNDING"
b m3_cmsis       TARGET=cortex_m_qemu TARGET_ARCH=cortex-m3 OPTIMIZED_KERNEL_DIR=cmsis_nn "ADDITIONAL_DEFINES=-DCMSIS_NN -DRQ1_NO_TRACE"
b m55_cmsis      TARGET=cortex_m_qemu_hf TARGET_ARCH=cortex-m55 OPTIMIZED_KERNEL_DIR=cmsis_nn "ADDITIONAL_DEFINES=-DCMSIS_NN -DRQ1_NO_TRACE"
b m0p_ref        TARGET=cortex_m_qemu TARGET_ARCH=cortex-m0plus "ADDITIONAL_DEFINES=-DRQ1_NO_TRACE"
echo done; ls gen_w2*/*/bin/w2_policy
