"""W2 closed-loop stress test: the same policy under harder conditions, one runtime from each rounding family.

Usage: python w2_stress.py OUT_DIR MODEL_NAME N_SEEDS
Stress: wheel slip sd 0.15 (nominal 0.10), ultrasonic dropout 0.40 (0.25), IR noise sd 0.05 (0.03).
"""
import functools
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import w2_sim as S  # noqa: E402
from w2_runtime import LineProc, LiteRT, ModelMeta, mcnemar_exact, run_episode  # noqa: E402

OUT, NAME, N = sys.argv[1], sys.argv[2], int(sys.argv[3])
STRESS = dict(obs_noise=0.05, us_noise=0.04, slip=0.15, us_dropout=0.40)
S.RowEnv.__init__ = functools.partialmethod(S.RowEnv.__init__, **STRESS)
meta = ModelMeta(os.path.join(OUT, "w2_models.json"), NAME)
mp = os.path.join(OUT, f"w2_actor_int8_{NAME}.tflite")
B = f"/home/claude/w2/bins/{NAME}"
rts = [("TFLM_reference_double_rounding", lambda: LineProc([f"{B}/x86_ref"], "x86_ref")),
       ("LiteRT_REF_single_rounding_family", lambda: LiteRT(mp, "REF")),
       ("LiteRT_XNNPACK", lambda: LiteRT(mp, "XNN"))]
seeds = list(range(5000, 5000 + N))
res = {}
for name, mk in rts:
    r = mk()
    eps = [run_episode(sd, r, meta)[0] for sd in seeds]
    r.close()
    res[name] = eps
ref = res[rts[0][0]]
out = {"stress": STRESS, "seeds": [seeds[0], seeds[-1]], "model": NAME}
for name, eps in res.items():
    b = sum(1 for x, y in zip(ref, eps) if x["success"] and not y["success"])
    c = sum(1 for x, y in zip(ref, eps) if not x["success"] and y["success"])
    out[name] = dict(success=sum(e["success"] for e in eps), n=len(eps), mean_rms_xte_m=float(np.mean([e["rms_xte"] for e in eps])),
                     vs_double_rounding=dict(ref_only=b, this_only=c, mcnemar_p=mcnemar_exact(b, c),
                                             changed_seeds=[x["seed"] for x, y in zip(ref, eps) if x["success"] != y["success"]]))
    print(name, json.dumps(out[name]), flush=True)
json.dump(out, open(os.path.join(OUT, f"stress_{NAME}.json"), "w"), indent=1)
