import sys, os, json, numpy as np
sys.modules["tensorflow"] = None
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
import w2_sim as S
torch.manual_seed(0); torch.set_num_threads(1)
env = make_vec_env(lambda: S.RowGym(), n_envs=4, seed=0)
for i, e in enumerate(env.envs): e.unwrapped._n = i * 1_000_000
model = PPO("MlpPolicy", env, seed=0, verbose=0, n_steps=1024, batch_size=256, n_epochs=10, gamma=0.998, gae_lambda=0.95,
            learning_rate=3e-4, policy_kwargs=dict(net_arch=dict(pi=[64, 64], vf=[64, 64]), activation_fn=torch.nn.ReLU, log_std_init=-0.5))
with torch.no_grad():
    model.policy.action_net.bias.fill_(0.6)
for it in range(4):
    model.learn(100_000, reset_num_timesteps=False)
    res=[]; acts=[]
    for sd in range(500, 520):
        e = S.RowEnv(sd); o = e.reset_obs()
        while not e.done:
            a,_ = model.predict(o, deterministic=True); acts.append(a); o,_,_ = e.step(a)
        res.append(e.metrics())
    acts=np.array(acts)
    print(json.dumps(dict(steps=(it+1)*100_000, success=sum(r['success'] for r in res), offtrack=sum((not r['success']) and r['steps']<600 for r in res),
        timeout=sum(r['steps']>=600 for r in res), mean_progress=round(float(np.mean([r['progress'] for r in res])),2), mean_steps=float(np.mean([r['steps'] for r in res])),
        mean_action=[round(float(v),3) for v in acts.mean(0)], log_std=[round(float(v),3) for v in model.policy.log_std.detach().numpy()])), flush=True)
