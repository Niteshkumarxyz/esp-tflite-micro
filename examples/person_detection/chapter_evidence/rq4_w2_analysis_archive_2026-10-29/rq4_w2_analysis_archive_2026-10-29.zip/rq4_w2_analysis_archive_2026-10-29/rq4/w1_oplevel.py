import sys, re, glob, json, hashlib
import numpy as np
src = open('/home/claude/arm/compare.py').read().split('# ESP32 R1 reference')[0]
exec(src)
esp = {}
for p in glob.glob('/mnt/user-data/uploads/robot-runtime-research/esp-tflite-micro/examples/person_detection/log.person_detection.202610252*.txt'):
    t = open(p, 'rb').read().decode('latin1').replace('\r', '')
    im = int(re.search(r'IMAGE_RESULT,image=(\d+)', t)[1]); ten, err = build(t); assert not err
    lat = int(re.search(r'latency_ms=(\d+)', t)[1])
    if lat > 60000: esp[im] = ten   # R1 dumps only
assert sorted(esp) == list(range(12))
t = open('/home/claude/arm/runs/m4_reference_SINGLE_ROUNDING.txt', 'rb').read().decode('latin1').replace('\r', '')
parts = re.split(r'^RQ1_IMAGE_BEGIN,image=(\d+)[ \t]*$', t, flags=re.M)
sr = {int(parts[i]): build(parts[i + 1])[0] for i in range(1, len(parts), 2)}
xnn = {int(l.split()[1]): l.split()[2:] for l in open('/home/claude/arm/xnn_hashes_litert230.txt')}
h = lambda b: hashlib.sha256(b).hexdigest()[:16]
S8 = lambda b: np.frombuffer(b, np.int8).astype(np.int32)
ops = []
for op in range(31):
    n = len(esp[0][op]); diffv = 0; tot = 0; maxlsb = 0; imgs_s = 0; imgs_x = 0
    for im in range(12):
        a, b = S8(esp[im][op]), S8(sr[im][op]); d = np.abs(a - b)
        diffv += int((d > 0).sum()); tot += len(a); maxlsb = max(maxlsb, int(d.max()))
        imgs_s += int((d > 0).any()); imgs_x += int(xnn[im][op] != h(esp[im][op]))
    ops.append(dict(op=op, n=n, S_frac_values_diff=diffv / tot, S_max_lsb=maxlsb, S_images_diff=imgs_s, X_images_diff=imgs_x))
tot_vals = sum(o['n'] for o in ops) * 12
print(json.dumps(dict(total_values=tot_vals, S_values_diff=sum(round(o['S_frac_values_diff'] * o['n'] * 12) for o in ops), ops=ops), indent=0)[:6000])
json.dump(ops, open('/home/claude/rq4/w1_oplevel.json', 'w'), indent=1)
