"""RQ4 on W1: what a K-image known-answer test would see, from recorded tensors (ESP32 R1 dumps, QEMU single-rounding run, LiteRT XNNPACK hashes)."""
import sys, re, glob, json, hashlib, itertools, math
sys.path.insert(0, '/home/claude/arm')
src = open('/home/claude/arm/compare.py').read().split('# ESP32 R1 reference')[0]
exec(src)  # brings build(), res()
esp = {}
for p in glob.glob('/mnt/user-data/uploads/robot-runtime-research/esp-tflite-micro/examples/person_detection/log.person_detection.202610252*.txt'):
    t = open(p, 'rb').read().decode('latin1').replace('\r', '')
    im = int(re.search(r'IMAGE_RESULT,image=(\d+)', t)[1]); ten, err = build(t); assert not err
    esp[im] = dict(ten=ten, out=res(t))
t = open('/home/claude/arm/runs/m4_reference_SINGLE_ROUNDING.txt', 'rb').read().decode('latin1').replace('\r', '')
parts = re.split(r'^RQ1_IMAGE_BEGIN,image=(\d+)[ \t]*$', t, flags=re.M)
sr = {}
for i in range(1, len(parts), 2):
    ten, err = build(parts[i + 1]); assert not err
    sr[int(parts[i])] = dict(ten=ten, out=res(parts[i + 1]))
xnn = {}
for line in open('/home/claude/arm/xnn_hashes_litert230.txt'):
    f = line.split(); xnn[int(f[1])] = f[2:]
h = lambda b: hashlib.sha256(b).hexdigest()[:16]
# check the hash convention on the images where XNNPACK should equal single rounding at every operator
conv_ok = sum(all(h(sr[i]['ten'][op]) == xnn[i][op] for op in range(31)) for i in range(12))
rows = []
for i in range(12):
    d_out, s_out = esp[i]['out'], sr[i]['out']
    first_s = next((op for op in range(31) if sr[i]['ten'][op] != esp[i]['ten'][op]), None)
    first_x = next((op for op in range(31) if xnn[i][op] != h(esp[i]['ten'][op])), None)
    x_out_eq_d = xnn[i][30] == h(esp[i]['ten'][30]); x_out_eq_s = xnn[i][30] == h(sr[i]['ten'][30])
    rows.append(dict(image=i, D=d_out[0], S=s_out[0], S_out_differs=d_out != s_out, S_first_op=first_s,
                     X_first_op=first_x, X_out_differs=not x_out_eq_d, X_out_equals_S=x_out_eq_s))
nS = sum(r['S_out_differs'] for r in rows); nX = sum(r['X_out_differs'] for r in rows)
def p_detect(n_bad, N, K):  # probability that K images drawn without replacement include at least one bad one
    return 1 - math.comb(N - n_bad, K) / math.comb(N, K) if K <= N else 1.0
out = dict(hash_convention_images_matching=conv_ok, rows=rows, S_output_changes=nS, X_output_changes=nX,
           output_level_detect={K: dict(S=p_detect(nS, 12, K), X=p_detect(nX, 12, K)) for K in (1, 2, 3, 4, 6)},
           tensor_level_detect_any_single_image=dict(S=all(r['S_first_op'] is not None for r in rows), X=all(r['X_first_op'] is not None for r in rows)))
print(json.dumps(out, indent=1)); json.dump(out, open('/home/claude/rq4/rq4_w1.json', 'w'), indent=1)
