"""Stress closed loop (same settings as w2_stress.py) for LiteRT OPT against double rounding (numpy re-implementation, checked bit-exact)."""
import functools, json, os, sys
import numpy as np
sys.path.insert(0, '/home/claude/w2'); sys.path.insert(0, '/home/claude/rq4')
import w2_sim as S
from w2_runtime import LiteRT, ModelMeta, mcnemar_exact, run_episode
from w2_int8_ref import W2Int8
NAME = sys.argv[1]
STRESS = dict(obs_noise=0.05, us_noise=0.04, slip=0.15, us_dropout=0.40)
S.RowEnv.__init__ = functools.partialmethod(S.RowEnv.__init__, **STRESS)
OUT = '/home/claude/w2/out'
meta = ModelMeta(os.path.join(OUT, 'w2_models.json'), NAME)
mp = os.path.join(OUT, f'w2_actor_int8_{NAME}.tflite')
class NumpyDouble:
    def __init__(self): self.net = W2Int8(mp)
    def act(self, q): return self.net.run_fast(q, 'double')[0]
    def close(self): pass
seeds = list(range(5000, 6000))
res = {}
for name, r in (('double_numpy', NumpyDouble()), ('LiteRT_OPT', LiteRT(mp, 'OPT'))):
    eps = []; trajs = []
    for sd in seeds:
        m, steps = run_episode(sd, r, meta, record=True); eps.append(m); trajs.append(b''.join(o + a for o, a in steps))
    r.close(); res[name] = (eps, trajs)
d, o = res['double_numpy'], res['LiteRT_OPT']
b = sum(1 for x, y in zip(d[0], o[0]) if x['success'] and not y['success'])
c = sum(1 for x, y in zip(d[0], o[0]) if not x['success'] and y['success'])
out = dict(model=NAME, stress=STRESS, double_success=sum(e['success'] for e in d[0]), opt_success=sum(e['success'] for e in o[0]),
           identical_trajectories=sum(x == y for x, y in zip(d[1], o[1])), double_only=b, opt_only=c, mcnemar_p=mcnemar_exact(b, c),
           changed_seeds=[x['seed'] for x, y in zip(d[0], o[0]) if x['success'] != y['success']])
print(json.dumps(out)); json.dump(out, open(f'/home/claude/rq4/stress_opt_{NAME}.json', 'w'), indent=1)
