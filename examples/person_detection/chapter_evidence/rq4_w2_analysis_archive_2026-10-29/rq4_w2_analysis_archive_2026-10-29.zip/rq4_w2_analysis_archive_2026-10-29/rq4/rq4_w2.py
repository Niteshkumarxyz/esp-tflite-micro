"""RQ4 on W2: detection of recorded runtime variants by a K-vector known-answer test, random vs rounding-tie selection."""
import sys, json, math
import numpy as np
sys.path.insert(0, '/home/claude/rq4')
from w2_int8_ref import W2Int8, mbqm_double, mbqm_single
R = {}
for m in ['per_tensor', 'per_channel']:
    E = f'/home/claude/w2/out/eval_{m}/'
    X = np.load(E + 'openloop_obs_int8.npy'); N = len(X)
    net = W2Int8(f'/home/claude/w2/out/w2_actor_int8_{m}.tflite')
    D, accs = net.run(X, 'double', record=True)
    load = lambda n: np.load(E + f'openloop_actions_{n}.npy')
    assert np.array_equal(D, load('TFLM_x86_reference'))
    same_as_D = {n: bool(np.array_equal(load(n), D)) for n in ['QEMU_M0plus_reference', 'QEMU_M3_CMSIS-NN_pureC', 'QEMU_M4_CMSIS-NN', 'QEMU_M4_reference', 'QEMU_M55_CMSIS-NN_MVE', 'TFLM_x86_reference']}
    variants = {'single_rounding': load('TFLM_x86_single_rounding'), 'XNNPACK': load('LiteRT_XNNPACK'), 'LiteRT_OPT': load('LiteRT_OPT'),
                'CMSIS-NN_single_rounding': load('QEMU_M4_CMSIS-NN_single_rounding'), 'LiteRT_REF': load('LiteRT_REF')}
    bad = {k: (v != D).any(1) for k, v in variants.items()}
    # operator-level view: first layer at which single rounding departs from double rounding, propagating each mode's own values
    h_d = X.astype(np.int64); h_s = X.astype(np.int64); first_layer = np.full(N, -1)
    for li, L in enumerate(net.layers):
        outs = []
        for h, f in ((h_d, mbqm_double), (h_s, mbqm_single)):
            acc = (h - L['in_zp']) @ L['W'].T + L['B']
            o = np.stack([f(acc[:, c], int(L['M0'][c]), int(L['sh'][c])) for c in range(acc.shape[1])], 1)
            outs.append(np.clip(o + L['out_zp'], -128, 127))
        h_d, h_s = outs
        diff = (h_d != h_s).any(1)
        first_layer[(first_layer < 0) & diff] = li
    # rounding-tie score from the qualified (double-rounding) arithmetic only: distance of the exact scaled value to the nearest .5
    score = np.full(N, np.inf)
    for L, acc in zip(net.layers, accs):
        for c in range(acc.shape[1]):
            total = 31 - int(L['sh'][c])
            exact = acc[:, c].astype(np.float64) * float(L['M0'][c]) / float(2 ** total)
            dist = np.abs(exact - np.floor(exact) - 0.5)
            score = np.minimum(score, dist)
    order = np.argsort(score, kind='stable')
    res = dict(N=N, negative_controls_identical=same_as_D,
               first_layer_single_vs_double={str(k): int((first_layer == k).sum()) for k in (-1, 0, 1, 2)},
               variants={})
    for k, b in bad.items():
        nb = int(b.sum()); row = dict(n_disagree=nb, rate=nb / N, random={}, tie_ranked={})
        for K in (16, 64, 256, 1024):
            row['random'][K] = 1 - math.exp(math.lgamma(N - nb + 1) - math.lgamma(N - nb - K + 1) - math.lgamma(N + 1) + math.lgamma(N - K + 1)) if nb else 0.0
            row['tie_ranked'][K] = int(b[order[:K]].sum())
        # rank of the first detecting vector under tie ordering
        hits = np.nonzero(b[order])[0]; row['tie_first_hit_rank'] = int(hits[0]) + 1 if len(hits) else None
        res['variants'][k] = row
    res['tie_score_quantiles'] = {q: float(np.quantile(score, q)) for q in (0.001, 0.01, 0.5)}
    R[m] = res
print(json.dumps(R, indent=1)); json.dump(R, open('/home/claude/rq4/rq4_w2.json', 'w'), indent=1)
