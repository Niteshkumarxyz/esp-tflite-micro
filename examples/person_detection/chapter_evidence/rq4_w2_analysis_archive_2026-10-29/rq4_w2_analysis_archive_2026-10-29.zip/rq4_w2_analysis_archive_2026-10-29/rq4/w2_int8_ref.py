"""Bit-level re-implementation of TFLM int8 FULLY_CONNECTED (double rounding and TFLITE_SINGLE_ROUNDING) for the W2 policy."""
import math
import numpy as np
from ai_edge_litert.interpreter import Interpreter

def quantize_multiplier(m):
    if m == 0.0:
        return 0, 0
    q, shift = math.frexp(m)
    q_fixed = int(round_half_away(q * (1 << 31)))
    if q_fixed == (1 << 31):
        q_fixed //= 2; shift += 1
    if shift < -31:
        shift, q_fixed = 0, 0
    return q_fixed, shift

def round_half_away(x):
    return math.floor(x + 0.5) if x >= 0 else -math.floor(-x + 0.5)

def mbqm_double(x, M0, shift):
    """gemmlowp SaturatingRoundingDoublingHighMul + RoundingDivideByPOT, vectorised on int64 arrays."""
    x = x.astype(np.int64)
    left = shift if shift > 0 else 0
    right = 0 if shift > 0 else -shift
    a = x * (1 << left)
    ab = a * np.int64(M0)
    nudge = np.where(ab >= 0, np.int64(1 << 30), np.int64(1 - (1 << 30)))
    s = ab + nudge
    hi = np.where(s >= 0, s // (1 << 31), -((-s) // (1 << 31)))  # C++ truncating division
    if right == 0:
        return hi
    mask = (1 << right) - 1
    rem = hi & mask
    thr = (mask >> 1) + (hi < 0).astype(np.int64)
    return (hi >> right) + (rem > thr).astype(np.int64)

def mbqm_single(x, M0, shift):
    x = x.astype(np.int64)
    total = 31 - shift
    rnd = np.int64(1) << np.int64(total - 1)
    return (x * np.int64(M0) + rnd) >> np.int64(total)

class W2Int8:
    def __init__(self, path):
        it = Interpreter(model_path=path); it.allocate_tensors()
        det = {d['index']: d for d in it.get_tensor_details()}
        self.layers = []
        for op in it._get_ops_details():
            if op['op_name'] != 'FULLY_CONNECTED':
                continue
            i, w, b = op['inputs']; o = op['outputs'][0]
            qi, qw, qo = det[i]['quantization_parameters'], det[w]['quantization_parameters'], det[o]['quantization_parameters']
            W = it.get_tensor(w).astype(np.int64); B = it.get_tensor(b).astype(np.int64)
            s_in = float(np.float32(qi['scales'][0])); s_out = float(np.float32(qo['scales'][0]))
            ws = np.asarray(qw['scales'], dtype=np.float32)
            if len(ws) == 1:
                ws = np.repeat(ws, W.shape[0])
            mult = [quantize_multiplier(s_in * float(ws[c]) / s_out) for c in range(W.shape[0])]
            self.layers.append(dict(W=W, B=B, in_zp=int(qi['zero_points'][0]), out_zp=int(qo['zero_points'][0]),
                                    M0=np.array([m[0] for m in mult], np.int64), sh=np.array([m[1] for m in mult], np.int64),
                                    exact=np.array([s_in * float(ws[c]) / s_out for c in range(W.shape[0])])))
    def run(self, X, mode="double", record=False):
        """X: (N,7) int8. Returns (N,2) int8 and, with record, per-layer accumulators."""
        h = X.astype(np.int64); accs = []
        for L in self.layers:
            acc = (h - L['in_zp']) @ L['W'].T + L['B']
            if record: accs.append(acc)
            out = np.empty_like(acc)
            for c in range(acc.shape[1]):
                f = mbqm_double if mode == "double" else mbqm_single
                out[:, c] = f(acc[:, c], int(L['M0'][c]), int(L['sh'][c]))
            h = np.clip(out + L['out_zp'], -128, 127)
        return (h.astype(np.int8), accs) if record else h.astype(np.int8)

def _dbl_vec(acc, M0, sh):
    left = np.maximum(sh, 0); right = np.maximum(-sh, 0)
    a = acc * (np.int64(1) << left)
    ab = a * M0
    s = ab + np.where(ab >= 0, np.int64(1 << 30), np.int64(1 - (1 << 30)))
    hi = np.where(s >= 0, s // (1 << 31), -((-s) // (1 << 31)))
    mask = (np.int64(1) << right) - 1
    rem = hi & mask
    thr = (mask >> 1) + (hi < 0).astype(np.int64)
    return (hi >> right) + (rem > thr).astype(np.int64)

def _sgl_vec(acc, M0, sh):
    total = 31 - sh
    return (acc * M0 + (np.int64(1) << (total - 1))) >> total

def run_fast(self, X, mode="double"):
    h = np.asarray(X, np.int64).reshape(-1, self.layers[0]['W'].shape[1])
    f = _dbl_vec if mode == "double" else _sgl_vec
    for L in self.layers:
        acc = (h - L['in_zp']) @ L['W'].T + L['B']
        h = np.clip(f(acc, L['M0'][None, :], L['sh'][None, :]) + L['out_zp'], -128, 127)
    return h.astype(np.int8)
W2Int8.run_fast = run_fast
