﻿# Normal R2 vs. Skip-Nudge R2 — Final Evidence

Date: 2026-10-28

## Result
The final comparison passed for all 12 static test images.
Each image has 3,625 raw tensor records in each build; zero differing
raw-record lines were found. Final INT8 output values matched for all
12 images. Each build had 31 RQ1_TRACE summary records per image.

Across the 12 images, 43,500 raw records per build were compared.

## Firmware identities
Normal optimized R2 BIN SHA-256:
F70EA1D4FF93289BB32BB3C89B20A70C3C232264B1B9B3793BEC43EB94D9F4BE

Skip-nudge R2 BIN SHA-256:
F8957C85437CA1AF1293447058CAABAEDAB3C0280EA580AE8397B9CAC33F2994

## Scope and limitations
The result establishes byte-identical captured RQ1_RAW records and
matching final INT8 outputs for these 12 tested static images on this
ESP32/model/runtime configuration. It does not establish equivalence
for all possible inputs or a performance improvement.

Latencies printed while emitting the large serial raw trace are not
normal inference benchmark measurements. RQ1_TRACE counts were checked;
the final comparison compared raw records and final outputs, not the
contents of each RQ1_TRACE summary line.

## Package structure
baseline_normal_r2: selected complete raw trace logs for images 0–11.
skip_nudge_r2: selected complete raw trace logs for images 0–11.
reports: comparison, integrity audit, and capture summary CSVs.
firmware: both build binaries, ELF files, and configuration snapshots.

SHA256_manifest.csv lists hashes for packaged files other than the
manifest itself. A separate sidecar records the ZIP hash.
