#ifndef RQ1_DATA_H_
#define RQ1_DATA_H_
extern const unsigned char g_rq1_model[];
extern const int g_rq1_model_len;
extern const unsigned char g_rq1_images_u8[12][9216];
#endif
