// RQ1 Arm study harness: runs the ESP32 person_detect model on the 12 ESP32 inputs.
// Mirrors ESP32 main_functions.cc: same 5-op resolver, uint8 -> int8 by XOR 0x80, output index 1 = person.
#include <stdint.h>
#include <stdio.h>
#include "tensorflow/lite/micro/examples/rq1_arm/rq1_data.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/schema/schema_generated.h"

namespace {
constexpr int kArenaSize = 200 * 1024;
alignas(16) uint8_t tensor_arena[kArenaSize];
}

int main(int argc, char** argv) {
  const tflite::Model* model = tflite::GetModel(g_rq1_model);
  static tflite::MicroMutableOpResolver<5> resolver;
  resolver.AddAveragePool2D();
  resolver.AddConv2D();
  resolver.AddDepthwiseConv2D();
  resolver.AddReshape();
  resolver.AddSoftmax();
  static tflite::MicroInterpreter interpreter(model, resolver, tensor_arena, kArenaSize);
  if (interpreter.AllocateTensors() != kTfLiteOk) { MicroPrintf("RQ1_ERROR,allocate"); return 1; }
  MicroPrintf("ARENA_USED_BYTES=%d", (int)interpreter.arena_used_bytes());
  TfLiteTensor* input = interpreter.input(0);
  for (int image = 0; image < 12; ++image) {
    for (int i = 0; i < 9216; ++i) input->data.int8[i] = (int8_t)(g_rq1_images_u8[image][i] ^ 0x80);
    MicroPrintf("RQ1_IMAGE_BEGIN,image=%d", image);
    TfLiteStatus s = interpreter.Invoke();
    TfLiteTensor* out = interpreter.output(0);
    MicroPrintf("IMAGE_RESULT,image=%d,invoke_ok=%d,person_raw_int8=%d,no_person_raw_int8=%d", image,
                s == kTfLiteOk ? 1 : 0, (int)out->data.int8[1], (int)out->data.int8[0]);
  }
  MicroPrintf("RQ1_DONE");
  return 0;
}
