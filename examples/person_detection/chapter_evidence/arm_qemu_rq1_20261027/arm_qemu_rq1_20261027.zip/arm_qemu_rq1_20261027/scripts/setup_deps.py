import subprocess,json,sys,shutil,os
from pathlib import Path
root=Path('/home/claude/arm/tflm'); D=root/'tensorflow/lite/micro/tools/make/downloads'
sys.path.insert(0,str(root/'tensorflow/lite/micro/tools/make'))
import download_dependencies as dd
def clone(repo,ref,dest):
    if dest.exists(): shutil.rmtree(dest)
    subprocess.run(['git','clone','-q',repo,str(dest)],check=True)
    subprocess.run(['git','-c','advice.detachedHead=false','checkout','-q',ref],cwd=dest,check=True)
    sha=subprocess.run(['git','rev-parse','HEAD'],cwd=dest,capture_output=True,text=True).stdout.strip()
    shutil.rmtree(dest/'.git'); return sha
log={}
for name,repo,ref in [('flatbuffers','https://github.com/google/flatbuffers.git','v25.9.23'),('kissfft','https://github.com/mborgerding/kissfft.git','v130'),('eyalroz_printf','https://github.com/eyalroz/printf.git','f8ed5a9bd9fa8384430973465e94aa14c925872d')]:
    dep=dd.DEPENDENCIES[name]; dest=D/name
    log[name]=clone(repo,ref,dest)
    if dep.patch: dd.apply_patch(root/dep.patch,dest)
    json.dump(dd.compute_stamp_metadata(dep,root),open(dest/dd.STAMP_FILENAME,'w'))
log['cmsis']=clone('https://github.com/ARM-software/CMSIS_6.git','5782d6f8057906d360f4b95ec08a2354afe5c9b9',D/'cmsis')
log['Cortex_DFP']=clone('https://github.com/ARM-software/Cortex_DFP.git','c2c70a97a20fb355815e2ead3d4a40e35a4a3cdf',D/'cmsis'/'Cortex_DFP')
log['cmsis_nn']=clone('https://github.com/ARM-software/CMSIS-NN.git','4ab83cc3cc98fb85ed6dafb55e8ca02f1628dcae',D/'cmsis_nn')
if not (D/'gcc_embedded').exists(): os.symlink('/home/claude/arm/xpack-arm-none-eabi-gcc-14.2.1-1.1',D/'gcc_embedded')
json.dump(log,open('/home/claude/arm/deps_commits.json','w'),indent=1); print(json.dumps(log,indent=1))
