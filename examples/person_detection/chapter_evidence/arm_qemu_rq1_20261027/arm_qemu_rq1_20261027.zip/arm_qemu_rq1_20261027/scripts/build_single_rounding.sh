#!/bin/bash
# Positive controls: documented single-rounding build options of TFLM and CMSIS-NN.
cd tflm
MK="make -s -j2 -f tensorflow/lite/micro/tools/make/Makefile -f ../rq1.mk"
$MK BASE_GENDIR=gen_sr TARGET=cortex_m_qemu TARGET_ARCH=cortex-m4 "ADDITIONAL_DEFINES=-DTFLITE_SINGLE_ROUNDING=1" rq1_arm_trace
$MK BASE_GENDIR=gen_sr TARGET=cortex_m_qemu TARGET_ARCH=cortex-m4 OPTIMIZED_KERNEL_DIR=cmsis_nn "ADDITIONAL_DEFINES=-DCMSIS_NN -DTFLITE_SINGLE_ROUNDING=1 -DCMSIS_NN_USE_SINGLE_ROUNDING" rq1_arm_trace
