#!/bin/bash
# Run every Arm/host build of the RQ1 harness; each run prints 12 images x 31 operator traces.
G=tflm/gen; R=runs; mkdir -p $R
qemu-arm -cpu cortex-m4  $G/cortex_m_qemu_cortex-m4_default_gcc/bin/rq1_arm_trace            > $R/m4_reference.txt
qemu-arm -cpu cortex-m4  $G/cortex_m_qemu_cortex-m4_default_cmsis_nn_gcc/bin/rq1_arm_trace   > $R/m4_cmsis_nn.txt
qemu-arm -cpu cortex-m3  $G/cortex_m_qemu_cortex-m3_default_cmsis_nn_gcc/bin/rq1_arm_trace   > $R/m3_cmsis_nn_scalar.txt
qemu-arm -cpu cortex-m55 $G/cortex_m_qemu_hf_cortex-m55_default_cmsis_nn_gcc/bin/rq1_arm_trace > $R/m55_cmsis_nn_mve.txt
qemu-arm -cpu cortex-m55 $G/cortex_m_qemu_hf_cortex-m55_default_gcc/bin/rq1_arm_trace        > $R/m55_reference.txt
qemu-arm -cpu cortex-m0  $G/cortex_m_qemu_cortex-m0plus_default_gcc/bin/rq1_arm_trace        > $R/m0plus_reference.txt
$G/linux_x86_64_default_gcc/bin/rq1_arm_trace                                               > $R/x86_reference_host.txt
qemu-arm -cpu cortex-m4  tflm/gen_sr/cortex_m_qemu_cortex-m4_default_gcc/bin/rq1_arm_trace          > $R/m4_reference_SINGLE_ROUNDING.txt
qemu-arm -cpu cortex-m4  tflm/gen_sr/cortex_m_qemu_cortex-m4_default_cmsis_nn_gcc/bin/rq1_arm_trace > $R/m4_cmsis_nn_SINGLE_ROUNDING.txt
