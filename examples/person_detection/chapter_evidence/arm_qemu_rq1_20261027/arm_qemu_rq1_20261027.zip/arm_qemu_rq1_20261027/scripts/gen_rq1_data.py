"""Regenerate tensorflow/lite/micro/examples/rq1_arm/rq1_data.{cc,h} from the ESP32 sources.
Model bytes are taken from esp-tflite-micro/examples/person_detection/main/person_detect_model_data.cc
(must hash to 808cfdfc...); inputs are static_images/sample_images/image0..11 (uint8, converted on device by XOR 0x80)."""
import hashlib, re, sys
src, imgdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
t = open(src).read(); body = t[t.index('{', t.index('g_person_detect_model_data')) + 1:]; body = body[:body.index('}')]
m = bytes(int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]{2})', body))
assert hashlib.sha256(m).hexdigest().startswith('808cfdfc'), 'model bytes differ from the ESP32 model'
imgs = [open(f'{imgdir}/image{i}', 'rb').read() for i in range(12)]
def arr(b): return ',\n'.join(','.join(str(v) for v in b[i:i + 32]) for i in range(0, len(b), 32))
with open(f'{out}/rq1_data.cc', 'w') as f:
    f.write('#include "tensorflow/lite/micro/examples/rq1_arm/rq1_data.h"\n')
    f.write('// person_detect model, %d bytes, SHA-256 %s (same bytes as ESP32 build)\n' % (len(m), hashlib.sha256(m).hexdigest()))
    f.write('alignas(16) const unsigned char g_rq1_model[%d] = {\n%s};\n' % (len(m), arr(m)))
    f.write('const int g_rq1_model_len = %d;\n' % len(m))
    f.write('// 12 inputs: static_images/sample_images/image0..11 (uint8), converted on device by XOR 0x80 exactly as ESP32 run_inference()\n')
    f.write('const unsigned char g_rq1_images_u8[12][9216] = {\n')
    for i, x in enumerate(imgs): f.write('{ // image%d sha256 %s\n%s},\n' % (i, hashlib.sha256(x).hexdigest(), arr(x)))
    f.write('};\n')
open(f'{out}/rq1_data.h', 'w').write('#ifndef RQ1_DATA_H_\n#define RQ1_DATA_H_\nextern const unsigned char g_rq1_model[];\nextern const int g_rq1_model_len;\nextern const unsigned char g_rq1_images_u8[12][9216];\n#endif\n')
