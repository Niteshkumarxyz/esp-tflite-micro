RQ1_SRCS := $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/rq1_arm/rq1_arm_main.cc \
            $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/rq1_arm/rq1_data.cc
RQ1_HDRS := $(TENSORFLOW_ROOT)tensorflow/lite/micro/examples/rq1_arm/rq1_data.h
$(eval $(call microlite_test,rq1_arm_trace,$(RQ1_SRCS),$(RQ1_HDRS),))
