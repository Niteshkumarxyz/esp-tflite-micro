"""Compare Arm/QEMU operator traces with ESP32 R1 full-dump traces (25 Oct). Reconstructs every tensor and checks stats."""
import re,glob,os,sys,json,hashlib,collections
TR=re.compile(r'^RQ1_TRACE,run=(\d+),op=(\d+),tensor=(\d+),n=(\d+),min=(-?\d+),max=(-?\d+),sum=(-?\d+),fnv1a=([0-9a-fA-F]+)[ \t]*$',re.M)
RW=re.compile(r'^RQ1_RAW,run=(\d+),op=(\d+),tensor=(\d+),offset=(\d+),count=(\d+),hex=([0-9a-fA-F]*)[ \t]*$',re.M)
def fnv(b):
    h=0x811c9dc5
    for x in b: h=((h^x)*0x01000193)&0xffffffff
    return h
def build(text):
    recs={};raws=collections.defaultdict(list);err=[]
    for m in TR.finditer(text): recs[int(m[2])]=(int(m[3]),int(m[4]),int(m[5]),int(m[6]),int(m[7]),int(m[8],16))
    for m in RW.finditer(text): raws[int(m[2])].append((int(m[4]),int(m[5]),bytes.fromhex(m[6])))
    ten={}
    for op,(tid,n,mn,mx,s,f) in recs.items():
        buf=bytearray(n);cov=bytearray(n)
        for off,cnt,b in raws[op]:
            if len(b)!=cnt: err.append(f'op{op} count')
            buf[off:off+len(b)]=b; cov[off:off+len(b)]=b'\x01'*len(b)
        if not all(cov): err.append(f'op{op} coverage')
        sv=[x-256 if x>127 else x for x in buf]
        if (n,min(sv),max(sv),sum(sv),fnv(bytes(buf)))!=(n,mn,mx,s,f): err.append(f'op{op} stats')
        ten[op]=bytes(buf)
    if sorted(recs)!=list(range(31)): err.append(f'ops {len(recs)}')
    return ten,err
def res(text):
    m=re.search(r'IMAGE_RESULT,image=(\d+),invoke_ok=(\d),person_raw_int8=(-?\d+),no_person_raw_int8=(-?\d+)',text.replace('\r','').replace('\n',''))
    return (int(m[3]),int(m[4])) if m else None
# ESP32 R1 reference
esp={}
for p in glob.glob('/mnt/user-data/uploads/robot-runtime-research/esp-tflite-micro/examples/person_detection/log.person_detection.202610252*.txt'):
    t=open(p,'rb').read().decode('latin1').replace('\r','')
    im=int(re.search(r'IMAGE_RESULT,image=(\d+)',t)[1]); ten,err=build(t)
    assert not err,(p,err)
    esp[im]=dict(ten=ten,out=res(t),file=os.path.basename(p),sha=hashlib.sha256(open(p,'rb').read()).hexdigest())
assert sorted(esp)==list(range(12)),sorted(esp)
def qemu(path):
    t=open(path,'rb').read().decode('latin1').replace('\r','')
    parts=re.split(r'^RQ1_IMAGE_BEGIN,image=(\d+)[ \t]*$',t,flags=re.M)
    out={}
    for i in range(1,len(parts),2):
        im=int(parts[i]); ten,err=build(parts[i+1]); out[im]=dict(ten=ten,err=err,out=res(parts[i+1]))
    arena=re.search(r'ARENA_USED_BYTES=(\d+)',t)
    return out,(int(arena[1]) if arena else None)
summary={}
for path in sorted(glob.glob('/home/claude/arm/runs/*.txt')):
    name=os.path.basename(path)[:-4]; q,arena=qemu(path)
    imgs=sorted(q); errs=sum(len(q[i]['err']) for i in imgs)
    same=dv=tot=0; first=[]; maxlsb=0; outs_same=0
    for im in imgs:
        a=q[im]['ten']; b=esp[im]['ten']; f=None
        for op in range(31):
            x,y=a[op],b[op]; tot+=len(x)
            d=[abs((u-256 if u>127 else u)-(v-256 if v>127 else v)) for u,v in zip(x,y) if u!=v]
            if not d and len(x)==len(y): same+=1
            else:
                dv+=len(d); maxlsb=max([maxlsb]+d)
                if f is None: f=op
        if f is not None: first.append((im,f))
        outs_same+= q[im]['out']==esp[im]['out']
    summary[name]=dict(images=len(imgs),struct_errors=errs,arena_used=arena,identical_tensors=f'{same}/{31*len(imgs)}',differing_values=dv,total_values=tot,max_lsb=maxlsb,first_divergent=first,outputs_equal=f'{outs_same}/{len(imgs)}',log_sha256=hashlib.sha256(open(path,'rb').read()).hexdigest())
    print(name,json.dumps(summary[name]))
json.dump(dict(esp_reference={k:dict(file=v['file'],sha256=v['sha'],out=v['out']) for k,v in esp.items()},arm=summary),open('/home/claude/arm/compare_summary.json','w'),indent=1)
