#!/bin/bash
cd /home/claude/arm/tflm
MK="make -s -j2 -f tensorflow/lite/micro/tools/make/Makefile -f /home/claude/arm/rq1.mk"
b(){ name=$1; shift; echo "=== $name $(date -u +%H:%M:%S)"; if timeout 2400 $MK "$@" rq1_arm_trace > /home/claude/arm/build_$name.log 2>&1; then echo "OK $name"; else echo "FAIL $name"; tail -5 /home/claude/arm/build_$name.log; fi; }
b m4_cmsis   TARGET=cortex_m_qemu    TARGET_ARCH=cortex-m4     OPTIMIZED_KERNEL_DIR=cmsis_nn
b m3_cmsis   TARGET=cortex_m_qemu    TARGET_ARCH=cortex-m3     OPTIMIZED_KERNEL_DIR=cmsis_nn
b m55_cmsis  TARGET=cortex_m_qemu_hf TARGET_ARCH=cortex-m55    OPTIMIZED_KERNEL_DIR=cmsis_nn
b m55_ref    TARGET=cortex_m_qemu_hf TARGET_ARCH=cortex-m55
b m0p_ref    TARGET=cortex_m_qemu    TARGET_ARCH=cortex-m0plus
b x86_ref
echo "=== done $(date -u +%H:%M:%S)"; ls -la gen/*/bin/rq1_arm_trace
