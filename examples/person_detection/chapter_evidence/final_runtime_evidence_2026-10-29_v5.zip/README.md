﻿# Final Runtime Evidence Package — V5

- Package date: 29 October 2026
- Target board: ESP32-D0WD-V3, revision 3.1
- ESP-IDF: v6.0.3
- Package revision: V5, based on the verified V4 archive plus the newly recaptured Normal R2 60-minute drift log and its independent audit.

## Included evidence

- Normal R2 and Skip-nudge firmware binaries and sdkconfig snapshots.
- Earlier RQ1 tensor-trace evidence and its comparison artifacts.
- Fresh Normal R2 and Skip-nudge 1,000-run IDF Monitor logs, SHA-256 sidecars and independent audit reports.
- Paired benchmark CSV and independent audit report.
- Normal R2 60-minute drift raw IDF Monitor log and independent audit report, added in V5.
- Artifact manifest containing file paths, byte lengths and SHA-256 hashes for all package files except the manifest itself.

## Fresh no-trace benchmark — 28 October 2026

Both raw benchmark logs contain 1,000 samples and report 1,000 successful runs with zero failures.

- Normal R2: mean 412500 us; exact median 412501.5 us; firmware-reported truncated median 412501 us; P95 nearest-rank 412582 us; minimum 412407 us; maximum 412583 us.
- Skip-nudge: exact mean 391103.7 us; truncated mean 391103 us; median 391107 us; P95 nearest-rank 391188 us; minimum 391015 us; maximum 391191 us.

The timing boundary is `interpreter_Invoke_only`. It is not whole-application latency or end-to-end robot-system latency.

## Paired Normal R2 vs. Skip-nudge comparison

The independent paired audit reports:

- 1,000 samples per configuration.
- Sample sequence, image order and successful-run status: PASS.
- Logged final INT8 Person and NoPerson output fields: 1,000/1,000 matched; zero mismatches.
- Mean paired latency difference, Normal R2 minus Skip-nudge: 21396.652 us.
- Observed mean latency reduction relative to Normal R2: 5.187%.

These captures use a repeated ten-image sequence, one 1,000-run capture per configuration. They are not a randomized multi-trial study. Matching final output fields does not establish intermediate-tensor equality for these fresh builds or equivalence for all possible inputs.

## Normal R2 60-minute drift — newly included in V5

Source file: `raw_logs_recapture_2026-10-28/normal_r2_drift_60min_idf_monitor_20261028_224705.txt`

- Raw log SHA-256: `B2868504977217FB079407F879733D71D7F26679ABDFFB728DB8E4FC8617FA14`
- Independent audit report: `raw_logs_recapture_2026-10-28/normal_r2_drift_60min_independent_audit_2026-10-28.md`
- Independent audit SHA-256: `095C321FED620BAFE40B9D51CD780934C2494B3E3F57E3D1F2A63C6EB9FE33D8`
- Minute samples: 60/60; duration: 3600 seconds.
- Total successful inference runs: 8571, matching the recorded DRIFT_END count.
- Failures: 0; output mismatches: 0; latency overflows: 0 minutes.
- Internal free memory was reported stable at 128720 bytes; no SPIRAM was present.
- Mean of the 60 minute-level mean latencies: approximately 412502.55 us.
- Mean of the minute-level reported P95 values: approximately 412586.517 us. This is an average of minute-level P95 summaries, not a global P95 calculated across every inference.
- Minute-level mean latency ranged from 412408 to 412607 us.

Firmware identity for the Normal R2 no-trace benchmark build: SHA-256 `B553E691EEC17E8E3DC1B1B39B4ACAB686AA90FAFFA6A6C1A1A0271F8FEE2DF0`.

## RQ1 traced tensor comparison

Earlier project evidence reports byte-for-byte identical raw INT8 tensor outputs for 372/372 comparisons across 12 static images and 31 traced operator/tensor output groups per image, for the specific recorded reference and optimized ESP-NN builds.

This is limited to the tested builds and inputs. It does not establish universal all-input equivalence, model accuracy or robot safety.

## Remaining limitations

- The dedicated raw log and independent audit for the previously reported Skip-nudge 60-minute drift run are not included in this package. Its historical summary must not be presented as independently re-audited from a raw log in this release.
- The paired fresh benchmark compares logged final outputs; it does not replace a fresh intermediate-tensor trace for those exact no-trace builds.
- The repeated ten-image benchmark and one capture per configuration do not supply randomized multi-trial uncertainty estimates.
- Physical rover operation, closed-loop control, energy consumption and robot-level safety have not been established by these measurements.
- Other platform or runtime results should be stated only when supporting measured evidence is available.

## Integrity

`artifact_manifest.csv` records byte length and SHA-256 for each staged file except the manifest itself. The ZIP checksum is recorded in an external sidecar. The separate release record documents archive size, hash, manifest count and extraction verification.
